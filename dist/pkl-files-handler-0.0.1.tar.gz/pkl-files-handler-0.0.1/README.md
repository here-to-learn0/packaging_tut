To make this sample package I have followed the following tutorial

https://packaging.python.org/tutorials/packaging-projects/